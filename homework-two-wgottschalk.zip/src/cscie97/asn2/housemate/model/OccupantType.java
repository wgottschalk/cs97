package cscie97.asn2.housemate.model;

public enum OccupantType {
    ADULT, CHILD, PET;
}
