package cscie97.asn2.housemate.model;

public enum OccupantStatus {
    ACTIVE, SLEEPING;
}
