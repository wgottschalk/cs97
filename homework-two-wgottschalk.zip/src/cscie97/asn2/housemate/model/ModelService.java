package cscie97.asn2.housemate.model;

import java.util.Map;

public interface ModelService {
    public void addOccupantToHouse(String occupantName, String houseName)
        throws EntityNotFoundException;

    public String createAppliance(String name, ApplianceType type, String room, int energyUsage)
        throws EntityAlreadyExistsException, EntityNotFoundException;
    public String createHouse(String name, String address)
        throws EntityAlreadyExistsException;
    public String createOccupant(String name, OccupantType type)
        throws EntityAlreadyExistsException;
    public String createRoom(String name, int floor, RoomType type, String houseName, int windows)
        throws EntityAlreadyExistsException, EntityNotFoundException;
    public String createSensor(String name, SensorType type, String room)
        throws EntityAlreadyExistsException, EntityNotFoundException;

    public boolean setDeviceStatus(String name, String status, String value)
        throws EntityNotFoundException;
    public Map<String, String> showDeviceStatus(String name)
        throws EntityNotFoundException;
    public String showDeviceStatus(String name, String status)
        throws EntityNotFoundException;

    // should this be Map<String, String>? or just String?
    public Map<String, String> showConfiguration();
    public Map<String, String> showConfiguration(String houseName)
        throws EntityNotFoundException;
    public Map<String, String> showConfiguration(String houseName, String roomName)
        throws EntityNotFoundException;
    public Map<String, String> showConfiguration(String houseName, String roomName, String applianceName)
        throws EntityNotFoundException;


    public int showEnergyUsage();
    public int showEnergyUsage(String houseName)
        throws EntityNotFoundException;
    public int showEnergyUsage(String houseName, String roomName)
        throws EntityNotFoundException;
    public int showEnergyUsage(String houseName, String roomName, String applianceName)
        throws EntityNotFoundException;
}

