package model.cscie97.asn3.housemate.controller;



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
public  interface HousemateController 
{

}

