package model.cscie97.asn3.housemate.controller;

import model.cscie97.asn3.housemate.model.Observable;
import model.Object;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
public  interface Observer 
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	
	public void update(Observable obs, Object data) ;


}

