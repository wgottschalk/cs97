package model.cscie97.asn3.housemate.controller;
import model.HousemateModelService;
import model.cscie97.asn3.housemate.model.Observable;
import model.Object;


/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public class HousemateControllerService implements HousemateController, Observer
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public HousemateControllerService(){
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	
	public HousemateController createController(HousemateModelService model) {
		// TODO implement me
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	
	public void update(Observable obs, Object data) {
		// TODO implement me
	}

}

