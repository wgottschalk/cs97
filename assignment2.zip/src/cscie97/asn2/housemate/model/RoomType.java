package cscie97.asn2.housemate.model;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 *
 * @generated
 */
public enum RoomType {
    KITCHEN, CLOSET, DINING_ROOM, LIVING_ROOM, BEDROOM, BATHROOM;
}
