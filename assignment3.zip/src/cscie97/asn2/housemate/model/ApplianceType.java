package cscie97.asn2.housemate.model;

public enum ApplianceType {
    THERMOSTAT, WINDOW, DOOR, LIGHT, TV, PANDORA, OVEN, REFRIGERATOR;
}