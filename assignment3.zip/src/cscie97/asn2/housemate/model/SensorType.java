package cscie97.asn2.housemate.model;

public enum SensorType {
    AVA, SMOKE_DETECTOR, CAMERA;
}
